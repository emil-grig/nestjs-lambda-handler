import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class S3HandlerService {
  private readonly logger = new Logger(S3HandlerService.name);

  handleS3Event(event: any): void {
    this.logger.log('S3 Event Received:', JSON.stringify(event, null, 2));
    console.log('S3 Event Received:', JSON.stringify(event, null, 2));
    for (const record of event.Records) {
      console.log(`Bucket: ${record.s3.bucket.name}`);
      console.log(`Object Key: ${record.s3.object.key}`);
      this.logger.log(`Bucket: ${record.s3.bucket.name}`);
      this.logger.log(`Object Key: ${record.s3.object.key}`);
    }
  }
}
