import { Module } from '@nestjs/common';
import { S3HandlerService } from './lambda.handler.service';

@Module({
  imports: [],
  providers: [S3HandlerService],
})
export class AppModule {}
